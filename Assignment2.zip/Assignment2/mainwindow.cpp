#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QImage>
#include <QPainter>
#include <QDebug>
#include <cmath>
#include <QElapsedTimer>
#include <QVector>
#include <QCoreApplication>
#include <QThread>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // Initialize the point for the next click
    currentClickAbsolute = QPoint(-1, -1);

    ui->spinBox->setValue(20);
    ui->spinBox_2->setValue(10); // Default radius
    drawGrid(ui->spinBox->value());
    // Initialize the computations label
    ui->label_3->setText("Computations: ");

    connect(ui->frame, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_Pressed()));
    connect(ui->frame, SIGNAL(sendMousePosition(QPoint&)), this, SLOT(showMousePosition(QPoint&)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMousePosition(QPoint &pos)
{
    sc_x = pos.x();
    sc_y = pos.y();

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    int graphX = floor((double)(sc_x - snappedOriginX) / gridSize);
    int graphY = floor((double)(sc_y - snappedOriginY) / gridSize);

    ui->mouse_movement->setText("Coordinate: (" + QString::number(graphX) + ", " + QString::number(graphY) + ")");
}

void MainWindow::Mouse_Pressed()
{
    org_x = sc_x;
    org_y = sc_y;

    // Store the absolute pixel coordinate of the click
    currentClickAbsolute = QPoint(org_x, org_y);


    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    // Highlight the box for immediate feedback
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int graphX = floor((double)(org_x - snappedOriginX) / gridSize);
    int graphY = floor((double)(org_y - snappedOriginY) / gridSize);
    ui->mouse_pressed->setText("Clicked: (" + QString::number(graphX) + ", " + QString::number(graphY) + ")");
    highlightBox(graphX, graphY, Qt::red);
}

void MainWindow::highlightBox(int gridX, int gridY, QColor color)
{
    if (ui->frame->pixmap().isNull()) return;
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    int pixelX = snappedOriginX + gridX * gridSize;
    int pixelY = snappedOriginY + gridY * gridSize;

    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    // QPainter automatically handles blending for colors with alpha channels
    painter.fillRect(pixelX, pixelY, gridSize, gridSize, color);
    painter.end();
    ui->frame->setPixmap(pm);
}

void MainWindow::plotCirclePoints(int centerX, int centerY, int x, int y, QColor color)
{
    highlightBox(centerX + x, centerY + y, color);
    highlightBox(centerX - x, centerY + y, color);
    highlightBox(centerX + x, centerY - y, color);
    highlightBox(centerX - x, centerY - y, color);
    highlightBox(centerX + y, centerY + x, color);
    highlightBox(centerX - y, centerY + x, color);
    highlightBox(centerX + y, centerY - x, color);
    highlightBox(centerX - y, centerY - x, color);
}

void MainWindow::drawGrid(int gridSize)
{
    QPixmap pix(ui->frame->width(), ui->frame->height());
    pix.fill(Qt::black);
    QPainter painter(&pix);
    if (gridSize > 0) {
        painter.setPen(Qt::NoPen);
        painter.setBrush(QBrush(QColor(50, 50, 50)));
        int centerX = pix.width() / 2;
        int centerY = pix.height() / 2;
        int snappedOriginX = centerX - (centerX % gridSize);
        int snappedOriginY = centerY - (centerY % gridSize);
        painter.drawRect(0, snappedOriginY, pix.width(), gridSize);
        painter.drawRect(snappedOriginX, 0, gridSize, pix.height());
        painter.setPen(QPen(Qt::darkGray, 1));
        for (int x = 0; x < pix.width(); x += gridSize) {
            painter.drawLine(x, 0, x, pix.height());
        }
        for (int y = 0; y < pix.height(); y += gridSize) {
            painter.drawLine(0, y, pix.width(), y);
        }
    }
    painter.end();
    ui->frame->setPixmap(pix);
}

void MainWindow::on_clear_clicked()
{
    // Clear the list of drawn circles
    drawnCircles.clear();
    currentClickAbsolute = QPoint(-1, -1);
    drawGrid(ui->spinBox->value());
    ui->label->setText("Time: ");
    ui->label_2->setText("Std Dev: ");
    // Clear the computations label
    ui->label_3->setText("Computations: ");
}

void MainWindow::animatePoints(const QVector<QPoint> &points, int centerX, int centerY, QColor color, int delay_ms)
{
    // This function is used by all algorithms
    for(const QPoint &p : points) {
        plotCirclePoints(centerX, centerY, p.x(), p.y(), color);
        QCoreApplication::processEvents();
        QThread::msleep(delay_ms);
    }
}

void MainWindow::on_draw_line_clicked() // Polar Circle
{
    if (currentClickAbsolute.x() == -1) return; // No center point clicked
    int radius = ui->spinBox_2->value();
    if (radius <= 0) return;

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int cx = floor((double)(currentClickAbsolute.x() - snappedOriginX) / gridSize);
    int cy = floor((double)(currentClickAbsolute.y() - snappedOriginY) / gridSize);

    QElapsedTimer timer;
    qint64 timings[10];
    QVector<QPoint> pointsToDraw;

    for (int k = 0; k < 10; ++k) {
        timer.start();
        pointsToDraw.clear();
        float theta_step = 1.0 / (2 * radius);
        for (float theta = 0; theta <= M_PI / 4; theta += theta_step) {
            int x = round(radius * cos(theta));
            int y = round(radius * sin(theta));
            pointsToDraw.append(QPoint(x,y));
        }
        timings[k] = timer.nsecsElapsed();
    }

    double sum = 0;
    for(int i = 0; i < 10; ++i) sum += timings[i];
    double average = sum / 10.0;
    double sq_sum_diff = 0;
    for(int i = 0; i < 10; ++i) sq_sum_diff += pow(timings[i] - average, 2);
    double std_dev = sqrt(sq_sum_diff / 9.0);

    ui->label->setText("Polar Circle Avg: " + QString::number(average, 'f', 2) + " ns");
    ui->label_2->setText("Std Dev: " + QString::number(std_dev, 'f', 2) + " ns");
    ui->label_3->setText("Computations: " + QString::number(pointsToDraw.size()));

    animatePoints(pointsToDraw, cx, cy, Qt::cyan, 100);

    // Store the drawn circle's data
    drawnCircles.append({QPoint(cx, cy), radius, CircleData::Polar});
}

void MainWindow::on_pushButton_2_clicked() // Midpoint Circle
{
    if (currentClickAbsolute.x() == -1) return; // No center point clicked
    int radius = ui->spinBox_2->value();
    if (radius <= 0) return;

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int cx = floor((double)(currentClickAbsolute.x() - snappedOriginX) / gridSize);
    int cy = floor((double)(currentClickAbsolute.y() - snappedOriginY) / gridSize);

    QElapsedTimer timer;
    qint64 timings[10];
    QVector<QPoint> pointsToDraw;

    for (int k = 0; k < 10; ++k) {
        timer.start();
        pointsToDraw.clear();
        int x = 0;
        int y = radius;
        int p = 1 - radius; // Initial decision parameter

        while (x <= y) {
            pointsToDraw.append(QPoint(x, y));
            x++;
            if (p < 0) {
                p = p + 2 * x + 1;
            } else {
                y--;
                p = p + 2 * (x - y) + 1;
            }
        }
        timings[k] = timer.nsecsElapsed();
    }

    double sum = 0;
    for(int i = 0; i < 10; ++i) sum += timings[i];
    double average = sum / 10.0;
    double sq_sum_diff = 0;
    for(int i = 0; i < 10; ++i) sq_sum_diff += pow(timings[i] - average, 2);
    double std_dev = sqrt(sq_sum_diff / 9.0);


    ui->label->setText("Midpoint Circle Avg: " + QString::number(average, 'f', 2) + " ns");
    ui->label_2->setText("Std Dev: " + QString::number(std_dev, 'f', 2) + " ns");
    ui->label_3->setText("Computations: " + QString::number(pointsToDraw.size()));

    animatePoints(pointsToDraw, cx, cy, Qt::yellow, 100);

    // Store the drawn circle's data
    drawnCircles.append({QPoint(cx, cy), radius, CircleData::Midpoint});
}

void MainWindow::on_draw_circle_cartesian_clicked()
{
    if (currentClickAbsolute.x() == -1) return; // No center point clicked
    int radius = ui->spinBox_2->value();
    if (radius <= 0) return;

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int cx = floor((double)(currentClickAbsolute.x() - snappedOriginX) / gridSize);
    int cy = floor((double)(currentClickAbsolute.y() - snappedOriginY) / gridSize);

    QElapsedTimer timer;
    qint64 timings[10];
    QVector<QPoint> pointsToDraw;

    for (int k = 0; k < 10; ++k) {
        timer.start();
        pointsToDraw.clear();
        int x = 0;
        int y = radius;
        // Calculate points for one octant
        while (x <= y) {
            pointsToDraw.append(QPoint(x, y));
            x++;
            y = round(sqrt(pow(radius, 2) - pow(x, 2)));
        }
        timings[k] = timer.nsecsElapsed();
    }

    double sum = 0;
    for(int i = 0; i < 10; ++i) sum += timings[i];
    double average = sum / 10.0;
    double sq_sum_diff = 0;
    for(int i = 0; i < 10; ++i) sq_sum_diff += pow(timings[i] - average, 2);
    double std_dev = sqrt(sq_sum_diff / 9.0);

    ui->label->setText("Cartesian Avg: " + QString::number(average, 'f', 2) + " ns");
    ui->label_2->setText("Std Dev: " + QString::number(std_dev, 'f', 2) + " ns");
    ui->label_3->setText("Computations: " + QString::number(pointsToDraw.size()));

    animatePoints(pointsToDraw, cx, cy, QColor(255, 165, 0)); // Orange color for Cartesian

    // Store the drawn circle's data
    drawnCircles.append({QPoint(cx, cy), radius, CircleData::Cartesian});
}

void MainWindow::drawCircleInstantly(const CircleData &circle)
{
    int cx = circle.center.x();
    int cy = circle.center.y();
    int radius = circle.radius;

    if (circle.algo == CircleData::Polar) {
        QColor color = Qt::cyan;
        float theta_step = 1.0 / (2 * radius);
        for (float theta = 0; theta <= M_PI / 4 + 1e-5; theta += theta_step) {
            int x = round(radius * cos(theta));
            int y = round(radius * sin(theta));
            plotCirclePoints(cx, cy, x, y, color);
        }
    } else if (circle.algo == CircleData::Midpoint) {
        QColor color = Qt::yellow;
        int x = 0;
        int y = radius;
        int p = 1 - radius;

        while (x <= y) {
            plotCirclePoints(cx, cy, x, y, color);
            x++;
            if (p < 0) {
                p = p + 2 * x + 1;
            } else {
                y--;
                p = p + 2 * (x - y) + 1;
            }
        }
    } else if (circle.algo == CircleData::Cartesian) {
        QColor color = QColor(255, 165, 0); // Orange
        int x = 0;
        int y = radius;
        while (x <= y) {
            plotCirclePoints(cx, cy, x, y, color);
            x++;
            y = round(sqrt(pow(radius, 2) - pow(x, 2)));
        }
    }
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    // Redraw the grid first
    drawGrid(arg1);

    // Redraw all stored circles on the new grid
    for(const auto &circle : drawnCircles) {
        drawCircleInstantly(circle);
    }
}

void MainWindow::on_spinBox_2_valueChanged(int arg1)
{
    Q_UNUSED(arg1);
}

void MainWindow::on_pushButton_clicked()
{
    if (currentClickAbsolute.x() == -1) return;
    int radius = ui->spinBox_2->value();
    if (radius <= 0) return;

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    // Standard conversion from absolute pixel coordinates to grid coordinates
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int cx = floor((double)(currentClickAbsolute.x() - snappedOriginX) / gridSize);
    int cy = floor((double)(currentClickAbsolute.y() - snappedOriginY) / gridSize);

    // Set up our standard 10-run timing structure
    QElapsedTimer timer;
    qint64 timings[10];
    QVector<QPoint> pointsToDraw;

    for (int k = 0; k < 10; ++k) {
        timer.start();
        pointsToDraw.clear();
        // Calculate points for the first octant (0 to 45 degrees)
        double limit = radius / sqrt(2.0);
        for (int x = 0; x <= (int)ceil(limit); ++x) {
            // Solve for y: y = sqrt(r^2 - x^2)
            double y_exact = sqrt(pow(radius, 2) - pow(x, 2));
            int y = round(y_exact);

            if (pointsToDraw.isEmpty() || pointsToDraw.last() != QPoint(x, y)) {
                pointsToDraw.append(QPoint(x, y));
            }
        }

        timings[k] = timer.nsecsElapsed();
    }

    // Standard calculation for average and standard deviation
    double sum = 0;
    for(int i = 0; i < 10; ++i) sum += timings[i];
    double average = sum / 10.0;
    double sq_sum_diff = 0;
    for(int i = 0; i < 10; ++i) sq_sum_diff += pow(timings[i] - average, 2);
    double std_dev = sqrt(sq_sum_diff / 9.0);


    ui->label->setText("Cartesian Avg: " + QString::number(average, 'f', 2) + " ns");
    ui->label_2->setText("Std Dev: " + QString::number(std_dev, 'f', 2) + " ns");
    ui->label_3->setText("Computations: " + QString::number(pointsToDraw.size()));

    animatePoints(pointsToDraw, cx, cy, QColor(255, 165, 0)); // Orange color for Cartesian

    drawnCircles.append({QPoint(cx, cy), radius, CircleData::Cartesian});
}

