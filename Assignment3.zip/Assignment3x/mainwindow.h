#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QVector>
#include <QTimer>
#include <QElapsedTimer>
#include <QColor>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void showMousePosition(QPoint &pos);
    void Mouse_Pressed();
    void animateDrawingStep();

    // UI element slots
    void on_clear_clicked();
    void on_draw_line_clicked();      // Re-purposed for DDA Ellipse
    void on_pushButton_2_clicked();   // Re-purposed for Midpoint Ellipse
    void on_pushButton_3_clicked();   // Re-purposed for Cartesian Ellipse
    void on_spinBox_valueChanged(int arg1);   // Grid Size
    void on_spinBox_2_valueChanged(int arg1); // Major Axis (rx)
    void on_spinBox_3_valueChanged(int arg1); // Minor Axis (ry)


private:
    Ui::MainWindow *ui;

    // --- Type Definitions ---
    enum Algorithm {
        Ellipse_DDA,
        Ellipse_Bresenham,
        Ellipse_Cartesian
    };

    struct EllipseDef {
        QPoint centerGrid;
        int rx;
        int ry;
        Algorithm algo;
    };

    // --- Member Variables ---
    // Mouse and center coordinates
    int sc_x, sc_y;
    QPoint centerInGridCoords;

    // Data storage
    QVector<EllipseDef> drawnEllipses;
    EllipseDef currentAnimatingEllipse;

    // Animation control
    QTimer *animationTimer;
    QVector<QPoint> animationPointQueue;
    QPoint currentAnimationCenterGrid;
    QColor currentAnimationColor;
    QElapsedTimer calculationTimer;


    // --- Helper Functions ---
    void drawGrid(int gridSize);
    void highlightBox(int gridX, int gridY, QColor color);
    void plotEllipsePoints(int centerX, int centerY, int x, int y, QColor color);
    void startAnimation(const QVector<QPoint>& points, Algorithm algo);
    void redrawAllShapes();
};
#endif // MAINWINDOW_H

