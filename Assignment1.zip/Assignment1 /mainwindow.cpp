#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QImage>
#include <QPainter>
#include <QDebug>
#include <QColor>
#include <cstdlib>
#include <cmath>
#include <QElapsedTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    lastPoint1 = QPoint(-1, -1);
    lastPoint2 = QPoint(-1, -1);

    center = QPoint(ui->frame->width() / 2, ui->frame->height() / 2);

    QPixmap pix(ui->frame->width(), ui->frame->height());
    pix.fill(Qt::black);
    ui->frame->setPixmap(pix);

    on_pushButton_2_clicked();

    connect(ui->frame, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_Pressed()));
    connect(ui->frame, SIGNAL(sendMousePosition(QPoint&)), this, SLOT(showMousePosition(QPoint&)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMousePosition(QPoint &pos)
{
    ui->mouse_movement->setText("Abs X: " + QString::number(pos.x()) + ", Y: " + QString::number(pos.y()));

    QPoint relativePos = QPoint(pos.x() - center.x(), center.y() - pos.y());
    ui->relative_coords->setText("Rel X: " + QString::number(relativePos.x()) + ", Y: " + QString::number(relativePos.y()));
}

void MainWindow::Mouse_Pressed()
{
    int current_x = ui->mouse_movement->text().split(" ")[2].remove(',').toInt();
    int current_y = ui->mouse_movement->text().split(" ")[4].toInt();
    QPoint currentPoint(current_x, current_y);

    ui->mouse_pressed->setText("X : " + QString::number(current_x) + ", Y : " + QString::number(current_y));

    lastPoint1 = lastPoint2;
    lastPoint2 = currentPoint;
    addPatch(current_x, current_y, ui->spinBox->value(), QColor(95, 200, 255));
}

void MainWindow::addPatch(int x, int y, int gridSize, QColor color)
{
    if (gridSize <= 0) return;
    QPixmap pm = ui->frame->pixmap();
    if (pm.isNull()) return;

    int axis_origin_x = floor(static_cast<double>(center.x()) / gridSize) * gridSize;
    int axis_origin_y = floor(static_cast<double>(center.y()) / gridSize) * gridSize;
    int offset_x = x - axis_origin_x;
    int offset_y = y - axis_origin_y;
    int snapped_offset_x = floor(static_cast<double>(offset_x) / gridSize) * gridSize;
    int snapped_offset_y = floor(static_cast<double>(offset_y) / gridSize) * gridSize;
    int final_abs_x = axis_origin_x + snapped_offset_x;
    int final_abs_y = axis_origin_y + snapped_offset_y;

    QPainter painter(&pm);
    painter.setBrush(QBrush(color));
    painter.setPen(Qt::NoPen);
    painter.drawRect(final_abs_x, final_abs_y, gridSize, gridSize);
    painter.end();

    ui->frame->setPixmap(pm);
}

void MainWindow::on_clearLinesButton_clicked()
{
    drawnLines.clear();
    lastPoint1 = QPoint(-1, -1);
    lastPoint2 = QPoint(-1, -1);
    on_pushButton_2_clicked();
    qDebug()<<"-------------LINES CLEARED-------------";
}

void MainWindow::on_pushButton_2_clicked()
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    QPixmap pm(ui->frame->width(), ui->frame->height());
    pm.fill(Qt::black);
    QPainter painter(&pm);

    int axis_origin_x = floor(static_cast<double>(center.x()) / gridSize) * gridSize;
    int axis_origin_y = floor(static_cast<double>(center.y()) / gridSize) * gridSize;

    painter.setBrush(QBrush(Qt::white));
    painter.setPen(Qt::NoPen);
    for (int y = 0; y < ui->frame->height(); y += gridSize) {
        painter.drawRect(axis_origin_x, y, gridSize, gridSize);
    }
    for (int x = 0; x < ui->frame->width(); x += gridSize) {
        painter.drawRect(x, axis_origin_y, gridSize, gridSize);
    }

    painter.setPen(QPen(QColor(95, 200, 250), 1));
    for (int x = axis_origin_x; x <= ui->frame->width(); x += gridSize) { painter.drawLine(x, 0, x, ui->frame->height()); }
    for (int x = axis_origin_x; x >= 0; x -= gridSize) { painter.drawLine(x, 0, x, ui->frame->height()); }
    for (int y = axis_origin_y; y <= ui->frame->height(); y += gridSize) { painter.drawLine(0, y, ui->frame->width(), y); }
    for (int y = axis_origin_y; y >= 0; y -= gridSize) { painter.drawLine(0, y, ui->frame->width(), y); }

    painter.end();
    ui->frame->setPixmap(pm);
}

void MainWindow::on_DDA_clicked()
{
    if (lastPoint1 == QPoint(-1, -1) || lastPoint2 == QPoint(-1, -1)) return;

    QElapsedTimer timer;
    timer.start();

    DrawnLine line;
    line.startGrid = pixelToGrid(lastPoint1);
    line.endGrid = pixelToGrid(lastPoint2);
    line.algo = Algorithm::DDA;
    drawnLines.append(line);

    drawDDA(lastPoint1, lastPoint2);

    qint64 time = timer.nsecsElapsed();
    ui->time_label->setText("DDA Time: " + QString::number(time) + " ns");
}

void MainWindow::on_Bresenham_clicked()
{
    if (lastPoint1 == QPoint(-1, -1) || lastPoint2 == QPoint(-1, -1)) return;

    QElapsedTimer timer;
    timer.start();

    DrawnLine line;
    line.startGrid = pixelToGrid(lastPoint1);
    line.endGrid = pixelToGrid(lastPoint2);
    line.algo = Algorithm::Bresenham;
    drawnLines.append(line);

    drawBresenham(lastPoint1, lastPoint2);

    qint64 time = timer.nsecsElapsed();
    ui->time_label->setText("Bresenham Time: " + QString::number(time) + " ns");
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    Q_UNUSED(arg1);

    on_pushButton_2_clicked();

    for(const DrawnLine &line : drawnLines)
    {
        QPoint startPixel = gridToPixel(line.startGrid);
        QPoint endPixel = gridToPixel(line.endGrid);

        if(line.algo == Algorithm::DDA)
        {
            drawDDA(startPixel, endPixel);
        }
        else if(line.algo == Algorithm::Bresenham)
        {
            drawBresenham(startPixel, endPixel);
        }
    }
}

QPoint MainWindow::pixelToGrid(const QPoint& pixelPoint)
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return QPoint(0,0);

    int axis_origin_x = floor(static_cast<double>(center.x()) / gridSize) * gridSize;
    int axis_origin_y = floor(static_cast<double>(center.y()) / gridSize) * gridSize;

    int gridX = floor((pixelPoint.x() - axis_origin_x) / static_cast<double>(gridSize));
    int gridY = floor((pixelPoint.y() - axis_origin_y) / static_cast<double>(gridSize));

    return QPoint(gridX, gridY);
}

QPoint MainWindow::gridToPixel(const QPoint& gridPoint)
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return QPoint(0,0);

    int axis_origin_x = floor(static_cast<double>(center.x()) / gridSize) * gridSize;
    int axis_origin_y = floor(static_cast<double>(center.y()) / gridSize) * gridSize;

    int pixelX = (gridPoint.x() * gridSize) + axis_origin_x;
    int pixelY = (gridPoint.y() * gridSize) + axis_origin_y;

    return QPoint(pixelX, pixelY);
}

void MainWindow::drawDDA(const QPoint& start, const QPoint& end)
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    painter.setBrush(QBrush(QColor(247, 250, 86)));
    painter.setPen(Qt::NoPen);

    int dx = end.x() - start.x();
    int dy = end.y() - start.y();
    double x = start.x(), y = start.y();

    int step = (abs(dx) > abs(dy)) ? abs(dx) : abs(dy);
    if (step == 0) {
        addPatch(x, y, gridSize, QColor(247, 250, 86));
        return;
    }

    double xInc = (dx * 1.0) / step;
    double yInc = (dy * 1.0) / step;

    for(int i=0; i<=step;i++)
    {
        int final_x = floor(static_cast<double>(std::lround(x)) / gridSize) * gridSize;
        int final_y = floor(static_cast<double>(std::lround(y)) / gridSize) * gridSize;
        painter.drawRect(final_x, final_y, gridSize, gridSize);
        x += xInc;
        y += yInc;
    }

    painter.end();
    ui->frame->setPixmap(pm);
}

void MainWindow::drawBresenham(const QPoint& start, const QPoint& end)
{
    QPoint startGrid = pixelToGrid(start);
    QPoint endGrid = pixelToGrid(end);

    if (abs(endGrid.x() - startGrid.x()) >= abs(endGrid.y() - startGrid.y()))
        drawLineH(startGrid, endGrid);
    else
        drawLineV(startGrid, endGrid);
}

void MainWindow::drawLineH(const QPoint& p1, const QPoint& p2)
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    painter.setBrush(QBrush(QColor(255, 78, 78)));
    painter.setPen(Qt::NoPen);

    int x1 = p1.x(), y1 = p1.y();
    int x2 = p2.x(), y2 = p2.y();

    if(x1 > x2) { std::swap(x1, x2); std::swap(y1, y2); }

    int dx = x2 - x1;
    int dy = y2 - y1;
    int dir = (dy < 0) ? -1 : 1;
    dy = abs(dy);

    int p = 2*dy - dx;
    int y = y1;

    for(int x = x1; x <= x2; x++)
    {
        QPoint pixel = gridToPixel(QPoint(x, y));
        painter.drawRect(pixel.x(), pixel.y(), gridSize, gridSize);
        if(p >= 0)
        {
            y += dir;
            p -= 2*dx;
        }
        p += 2*dy;
    }

    painter.end();
    ui->frame->setPixmap(pm);
}

void MainWindow::drawLineV(const QPoint& p1, const QPoint& p2)
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    painter.setBrush(QBrush(QColor(255, 78, 78)));
    painter.setPen(Qt::NoPen);

    int x1 = p1.x(), y1 = p1.y();
    int x2 = p2.x(), y2 = p2.y();

    if(y1 > y2) { std::swap(x1, x2); std::swap(y1, y2); }

    int dx = x2 - x1;
    int dy = y2 - y1;
    int dir = (dx < 0) ? -1 : 1;
    dx = abs(dx);

    int p = 2*dx - dy;
    int x = x1;

    for(int y = y1; y <= y2; y++)
    {
        QPoint pixel = gridToPixel(QPoint(x, y));
        painter.drawRect(pixel.x(), pixel.y(), gridSize, gridSize);
        if(p >= 0)
        {
            x += dir;
            p -= 2*dy;
        }
        p += 2*dx;
    }

    painter.end();
    ui->frame->setPixmap(pm);
}
