#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QImage>
#include <QPainter>
#include <QDebug>
#include <cmath>
#include <QElapsedTimer>
#include <QVector>
#include <QStack>
#include <QThread>
#include <QCoreApplication>
#include <algorithm> // for std::sort and std::remove_if

// Edge structure for the scanline algorithm
struct Edge {
    int y_max;
    float x_min;
    float inv_slope;
    bool operator<(const Edge& other) const {
        return x_min < other.x_min;
    }
};

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    seedPoint = QPoint(-1, -1);
    settingSeedPoint = false;
    boundaryColor = Qt::white;
    originalSeedColor = Qt::black; // Default initialization

    ui->spinBox->setValue(20);
    drawGrid(ui->spinBox->value());

    connect(ui->frame, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_Pressed()));
    connect(ui->frame, SIGNAL(sendMousePosition(QPoint&)), this, SLOT(showMousePosition(QPoint&)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMousePosition(QPoint &pos)
{
    sc_x = pos.x();
    sc_y = pos.y();

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    int graphX = floor((double)(sc_x - snappedOriginX) / gridSize);
    int graphY = floor((double)(snappedOriginY - sc_y) / gridSize); // Flipped Y-axis

    ui->mouse_movement->setText("Coordinate: (" + QString::number(graphX) + ", " + QString::number(graphY) + ")");
}

void MainWindow::Mouse_Pressed()
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    // Convert screen coordinates to grid coordinates
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int gridX = floor((double)(sc_x - snappedOriginX) / gridSize);
    int gridY = floor((double)(snappedOriginY - sc_y) / gridSize); // Flipped Y-axis

    ui->mouse_pressed->setText("Clicked: (" + QString::number(gridX) + ", " + QString::number(gridY) + ")");

    if (settingSeedPoint)
    {
        seedPoint = QPoint(gridX, gridY);
        originalSeedColor = getPixelColor(gridX, gridY); // Store color before highlighting
        highlightBox(gridX, gridY, Qt::yellow);
        settingSeedPoint = false;
        ui->label->setText("Seed Set!");
    }
    else
    {
        QPoint newVertex(gridX, gridY);

        if (!polygonVertices.isEmpty() && newVertex == polygonVertices.first()) {
            if (polygonVertices.size() > 2) {
                drawPolygonEdge(polygonVertices.last(), polygonVertices.first());
                polygonVertices.append(newVertex); // Add closing point
            }
        } else {
            polygonVertices.append(newVertex);
            highlightBox(gridX, gridY, boundaryColor);
            if (polygonVertices.size() > 1) {
                drawPolygonEdge(polygonVertices.at(polygonVertices.size() - 2), newVertex);
            }
        }
    }
}

void MainWindow::drawGrid(int gridSize)
{
    QPixmap pix(ui->frame->width(), ui->frame->height());
    pix.fill(Qt::black);
    QPainter painter(&pix);

    if (gridSize <= 0) {
        ui->frame->setPixmap(pix);
        return;
    }

    // 1. Calculate the central snapped origin
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    // 2. Draw the thick axis bands using filled rectangles
    painter.setPen(Qt::NoPen); // No outline for the rectangles
    painter.setBrush(QBrush(QColor(50, 50, 50))); // Dark gray fill color

    // Draw the horizontal axis band (X-axis)
    painter.drawRect(0, snappedOriginY, pix.width(), gridSize);
    // Draw the vertical axis band (Y-axis)
    painter.drawRect(snappedOriginX, 0, gridSize, pix.height());

    // 3. Draw the thin grid lines on top of everything
    painter.setPen(QPen(Qt::darkGray, 1));
    // Draw vertical lines spreading out from the origin
    for (int x = snappedOriginX; x < pix.width(); x += gridSize) {
        painter.drawLine(x, 0, x, pix.height());
    }
    for (int x = snappedOriginX - gridSize; x >= 0; x -= gridSize) {
        painter.drawLine(x, 0, x, pix.height());
    }
    // Draw horizontal lines spreading out from the origin
    for (int y = snappedOriginY; y < pix.height(); y += gridSize) {
        painter.drawLine(0, y, pix.width(), y);
    }
    for (int y = snappedOriginY - gridSize; y >= 0; y -= gridSize) {
        painter.drawLine(0, y, pix.width(), y);
    }

    painter.end();
    ui->frame->setPixmap(pix);
}


void MainWindow::highlightBox(int gridX, int gridY, QColor color)
{
    if (ui->frame->pixmap().isNull()) return;
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    int pixelX = snappedOriginX + gridX * gridSize;
    int pixelY = snappedOriginY - (gridY + 1) * gridSize; // Adjusted for flipped Y-axis

    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    painter.fillRect(pixelX + 1, pixelY + 1, gridSize - 1, gridSize - 1, color);
    painter.end();
    ui->frame->setPixmap(pm);
}

void MainWindow::drawPolygonEdge(const QPoint& p1, const QPoint& p2) {
    int x1 = p1.x(), y1 = p1.y();
    int x2 = p2.x(), y2 = p2.y();

    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    if (steps == 0) {
        highlightBox(x1, y1, boundaryColor);
        return;
    }

    float x_inc = (float)dx / steps;
    float y_inc = (float)dy / steps;
    float x = x1, y = y1;

    for (int i = 0; i <= steps; i++) {
        highlightBox(round(x), round(y), boundaryColor);
        x += x_inc;
        y += y_inc;
    }
}

QColor MainWindow::getPixelColor(int gridX, int gridY) {
    int gridSize = ui->spinBox->value();
    if (gridSize <= 1) return Qt::black;

    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);

    int pixelX = snappedOriginX + gridX * gridSize;
    int pixelY = snappedOriginY - (gridY + 1) * gridSize; // Adjusted for flipped Y-axis

    QPoint samplePoint(pixelX + 1, pixelY + 1);

    QImage img = ui->frame->pixmap().toImage();
    if (img.valid(samplePoint)) {
        return img.pixelColor(samplePoint);
    }
    return Qt::black;
}

void MainWindow::redrawPolygon() {
    if (polygonVertices.isEmpty()) return;

    for(const QPoint& v : polygonVertices) {
        highlightBox(v.x(), v.y(), boundaryColor);
    }
    for(int i = 0; i < polygonVertices.size() - 1; ++i) {
        drawPolygonEdge(polygonVertices[i], polygonVertices[i+1]);
    }
    if(seedPoint.x() != -1) {
        highlightBox(seedPoint.x(), seedPoint.y(), Qt::yellow);
    }
}

void MainWindow::redrawBoundary() {
    if (polygonVertices.size() <= 1) return;

    // This loop redraws all the edges of the polygon
    for(int i = 0; i < polygonVertices.size() - 1; ++i) {
        drawPolygonEdge(polygonVertices[i], polygonVertices[i+1]);
    }
}

void MainWindow::on_clear_clicked()
{
    polygonVertices.clear();
    seedPoint = QPoint(-1, -1);
    originalSeedColor = Qt::black;
    settingSeedPoint = false;
    drawGrid(ui->spinBox->value());
    ui->label->setText("Cleared.");
    ui->label_2->setText("");
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    drawGrid(arg1);
    redrawPolygon();
}

void MainWindow::on_setSeed_clicked()
{
    settingSeedPoint = true;
    ui->label->setText("Click to set seed point...");
}

void MainWindow::on_boundaryFill_clicked()
{
    if (seedPoint.x() == -1) {
        ui->label->setText("Error: Seed point not set!");
        return;
    }

    QColor fillColor = Qt::blue;
    QColor currentSeedColor = originalSeedColor;

    if (currentSeedColor == boundaryColor || currentSeedColor == fillColor) {
        ui->label->setText("Error: Cannot fill - seed is boundary/fill color!");
        return;
    }

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int min_gx = floor((double)(0 - snappedOriginX) / gridSize);
    int max_gx = floor((double)(ui->frame->width() - 1 - snappedOriginX) / gridSize);
    int min_gy = floor((double)(snappedOriginY - (ui->frame->height() - 1)) / gridSize);
    int max_gy = floor((double)(snappedOriginY - 0) / gridSize);

    QStack<QPoint> stack;
    stack.push(seedPoint);

    QElapsedTimer timer;
    timer.start();

    while (!stack.isEmpty()) {
        QPoint p = stack.pop();

        if (p.x() < min_gx || p.x() > max_gx || p.y() < min_gy || p.y() > max_gy) {
            continue;
        }

        QColor currentColor = getPixelColor(p.x(), p.y());
        if (currentColor != boundaryColor && currentColor != fillColor) {
            highlightBox(p.x(), p.y(), fillColor);
            stack.push(QPoint(p.x() + 1, p.y()));
            stack.push(QPoint(p.x() - 1, p.y()));
            stack.push(QPoint(p.x(), p.y() + 1));
            stack.push(QPoint(p.x(), p.y() - 1));
            QCoreApplication::processEvents();
            QThread::msleep(1);
        }
    }
    ui->label->setText("Boundary Fill Time: " + QString::number(timer.elapsed()) + " ms");
}

void MainWindow::on_floodFill_clicked()
{
    if (seedPoint.x() == -1) {
        ui->label->setText("Error: Seed point not set!");
        return;
    }

    QColor fillColor = Qt::green;
    QColor targetColor = originalSeedColor;

    if (targetColor == fillColor) {
        ui->label->setText("Error: Target color is same as fill color!");
        return;
    }

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int min_gx = floor((double)(0 - snappedOriginX) / gridSize);
    int max_gx = floor((double)(ui->frame->width() - 1 - snappedOriginX) / gridSize);
    int min_gy = floor((double)(snappedOriginY - (ui->frame->height() - 1)) / gridSize);
    int max_gy = floor((double)(snappedOriginY - 0) / gridSize);

    QStack<QPoint> stack;
    stack.push(seedPoint);

    QElapsedTimer timer;
    timer.start();

    while (!stack.isEmpty()) {
        QPoint p = stack.pop();

        if (p.x() < min_gx || p.x() > max_gx || p.y() < min_gy || p.y() > max_gy) {
            continue;
        }

        QColor currentColor = getPixelColor(p.x(), p.y());

        bool shouldFill = (p == seedPoint && currentColor == Qt::yellow) || (currentColor == targetColor);

        if (shouldFill) {
            highlightBox(p.x(), p.y(), fillColor);
            stack.push(QPoint(p.x() + 1, p.y()));
            stack.push(QPoint(p.x() - 1, p.y()));
            stack.push(QPoint(p.x(), p.y() + 1));
            stack.push(QPoint(p.x(), p.y() - 1));
            QCoreApplication::processEvents();
            QThread::msleep(1);
        }
    }
    ui->label->setText("Flood Fill Time: " + QString::number(timer.elapsed()) + " ms");
}

void MainWindow::on_scanlineFill_clicked()
{
    if (polygonVertices.size() < 4) {
        ui->label->setText("Error: A polygon needs at least 3 vertices.");
        return;
    }
    if (polygonVertices.first() != polygonVertices.last()) {
        ui->label->setText("Error: Polygon must be closed first!");
        return;
    }

    QColor fillColor = Qt::magenta;
    int y_min = 10000, y_max = -10000;

    QVector<QPoint> vertices = polygonVertices;
    vertices.removeLast();

    for (const QPoint& v : vertices) {
        if (v.y() < y_min) y_min = v.y();
        if (v.y() > y_max) y_max = v.y();
    }

    int table_height = y_max - y_min + 1;
    QVector<QVector<Edge>> edgeTable(table_height);

    for (int i = 0; i < vertices.size(); ++i) {
        QPoint p1 = vertices[i];
        QPoint p2 = vertices[(i + 1) % vertices.size()];

        if (p1.y() == p2.y()) continue;

        int y_start_grid = std::min(p1.y(), p2.y());
        int y_end_grid = std::max(p1.y(), p2.y());
        float x_at_ymin = (p1.y() < p2.y()) ? p1.x() : p2.x();
        float inv_slope = (float)(p2.x() - p1.x()) / (p2.y() - p1.y());

        Edge e = {y_end_grid, x_at_ymin, inv_slope};
        int table_index = y_start_grid - y_min;
        if(table_index >= 0 && table_index < edgeTable.size())
            edgeTable[table_index].append(e);
    }

    QElapsedTimer timer;
    timer.start();

    QVector<Edge> activeEdgeTable;
    for (int y = y_min; y <= y_max; ++y) {
        int table_index = y - y_min;
        if(table_index >= 0 && table_index < edgeTable.size()){
            for (const Edge& e : edgeTable[table_index]) {
                activeEdgeTable.append(e);
            }
        }

        activeEdgeTable.erase(std::remove_if(activeEdgeTable.begin(), activeEdgeTable.end(),
                                             [y](const Edge& e) { return e.y_max <= y; }), activeEdgeTable.end());

        std::sort(activeEdgeTable.begin(), activeEdgeTable.end());

        for (int i = 0; i < activeEdgeTable.size(); i += 2) {
            if (i + 1 < activeEdgeTable.size()) {
                int x_start = ceil(activeEdgeTable[i].x_min);
                int x_end = floor(activeEdgeTable[i+1].x_min);

                // Reverted loop to fill the full span, including the border areas
                for (int x = x_start; x <= x_end; ++x) {
                    highlightBox(x, y, fillColor);
                }
            }
        }

        QCoreApplication::processEvents();
        QThread::msleep(10);

        for (Edge& e : activeEdgeTable) {
            e.x_min += e.inv_slope;
        }
    }

    // After the entire fill is done, redraw the boundary on top
    redrawBoundary();

    ui->label->setText("Scanline Fill Time: " + QString::number(timer.elapsed()) + " ms");
}

void MainWindow::on_pushButton_2_clicked()
{
    if (seedPoint.x() == -1) {
        ui->label->setText("Error: Seed point not set!");
        return;
    }

    QColor fillColor = Qt::blue;

    // Check the seed point's color before starting
    QColor seedColor = getPixelColor(seedPoint.x(), seedPoint.y());
    if (seedColor == boundaryColor || seedColor == fillColor) {
        ui->label->setText("Error: Cannot fill - seed is boundary/fill color!");
        return;
    }

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int min_gx = floor((double)(0 - snappedOriginX) / gridSize);
    int max_gx = floor((double)(ui->frame->width() - 1 - snappedOriginX) / gridSize);
    int min_gy = floor((double)(snappedOriginY - (ui->frame->height() - 1)) / gridSize);
    int max_gy = floor((double)(snappedOriginY - 0) / gridSize);

    QStack<QPoint> stack;
    stack.push(seedPoint);
    highlightBox(seedPoint.x(), seedPoint.y(), fillColor); // Color the seed point immediately to mark it as visited

    QElapsedTimer timer;
    timer.start();

    while (!stack.isEmpty()) {
        QPoint p = stack.pop();

        // Define the 8 neighbors
        const QPoint neighbors[8] = {
            QPoint(p.x() + 1, p.y()),
            QPoint(p.x() - 1, p.y()),
            QPoint(p.x(), p.y() + 1),
            QPoint(p.x(), p.y() - 1),
            QPoint(p.x() + 1, p.y() + 1),
            QPoint(p.x() - 1, p.y() + 1),
            QPoint(p.x() + 1, p.y() - 1),
            QPoint(p.x() - 1, p.y() - 1)
        };

        // Check each neighbor
        for (const QPoint& n : neighbors) {
            // Check bounds
            if (n.x() < min_gx || n.x() > max_gx || n.y() < min_gy || n.y() > max_gy) {
                continue;
            }

            // Check color
            QColor neighborColor = getPixelColor(n.x(), n.y());
            if (neighborColor != boundaryColor && neighborColor != fillColor) {
                // If valid, color it immediately and push it to the stack
                highlightBox(n.x(), n.y(), fillColor);
                stack.push(n);
            }
        }
        // Process events for visualization after checking all neighbors of a pixel
        QCoreApplication::processEvents();
        QThread::msleep(1);
    }
    ui->label->setText("Boundary Fill Time: " + QString::number(timer.elapsed()) + " ms");
}


void MainWindow::on_pushButton_clicked()
{
    if (seedPoint.x() == -1) {
        ui->label->setText("Error: Seed point not set!");
        return;
    }

    QColor fillColor = Qt::green;
    QColor targetColor = originalSeedColor;

    if (targetColor == fillColor) {
        ui->label->setText("Error: Target color is same as fill color!");
        return;
    }

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int min_gx = floor((double)(0 - snappedOriginX) / gridSize);
    int max_gx = floor((double)(ui->frame->width() - 1 - snappedOriginX) / gridSize);
    int min_gy = floor((double)(snappedOriginY - (ui->frame->height() - 1)) / gridSize);
    int max_gy = floor((double)(snappedOriginY - 0) / gridSize);

    QStack<QPoint> stack;
    stack.push(seedPoint);

    QElapsedTimer timer;
    timer.start();

    while (!stack.isEmpty()) {
        QPoint p = stack.pop();

        if (p.x() < min_gx || p.x() > max_gx || p.y() < min_gy || p.y() > max_gy) {
            continue;
        }

        QColor currentColor = getPixelColor(p.x(), p.y());

        bool shouldFill = (p == seedPoint && currentColor == Qt::yellow) || (currentColor == targetColor);

        if (shouldFill) {
            highlightBox(p.x(), p.y(), fillColor);

            // 4-connected neighbors
            stack.push(QPoint(p.x() + 1, p.y()));
            stack.push(QPoint(p.x() - 1, p.y()));
            stack.push(QPoint(p.x(), p.y() + 1));
            stack.push(QPoint(p.x(), p.y() - 1));

            // Add diagonal neighbors for 8-connectivity
            stack.push(QPoint(p.x() + 1, p.y() + 1)); // Top-right
            stack.push(QPoint(p.x() - 1, p.y() + 1)); // Top-left
            stack.push(QPoint(p.x() + 1, p.y() - 1)); // Bottom-right
            stack.push(QPoint(p.x() - 1, p.y() - 1)); // Bottom-left

            QCoreApplication::processEvents();
            QThread::msleep(1);
        }
    }
    ui->label->setText("Flood Fill Time: " + QString::number(timer.elapsed()) + " ms");
}
