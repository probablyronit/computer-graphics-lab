#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QColor>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Mouse interaction slots
    void Mouse_Pressed();
    void showMousePosition(QPoint &pos);

    // UI control slots
    void on_clear_clicked();
    void on_spinBox_valueChanged(int arg1);
    void on_setSeed_clicked();

    // Algorithm slots
    void on_boundaryFill_clicked();
    void on_floodFill_clicked();
    void on_scanlineFill_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    // UI pointer
    Ui::MainWindow *ui;

    // Member variables
    int sc_x, sc_y;
    QPoint seedPoint;
    bool settingSeedPoint;
    QColor boundaryColor;
    QColor originalSeedColor; // Important for fill algorithms
    QVector<QPoint> polygonVertices;

    // Helper functions
    void drawGrid(int gridSize);
    void highlightBox(int gridX, int gridY, QColor color);
    void drawPolygonEdge(const QPoint& p1, const QPoint& p2);
    QColor getPixelColor(int gridX, int gridY);
    void redrawPolygon();
    void redrawBoundary(); // New function added here
};

#endif // MAINWINDOW_H
