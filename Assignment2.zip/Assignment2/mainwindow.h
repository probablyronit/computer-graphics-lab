#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QColor>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void Mouse_Pressed();
    void showMousePosition(QPoint &pos);
    void on_clear_clicked();
    void on_draw_line_clicked(); // Polar Circle
    void on_pushButton_2_clicked(); // Midpoint Circle
    void on_draw_circle_cartesian_clicked();
    void on_spinBox_valueChanged(int arg1);
    void on_spinBox_2_valueChanged(int arg1);

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    int sc_x, sc_y;
    int org_x, org_y;

    // Data structure to store drawn circles
    struct CircleData {
        QPoint center; // Stored in GRID coordinates
        int radius;
        // Cartesian algorithm type
        enum Algorithm { Polar, Midpoint, Cartesian };
        Algorithm algo;
    };
    QVector<CircleData> drawnCircles;

    // Stores the absolute PIXEL coordinate of the last click
    QPoint currentClickAbsolute;

    void highlightBox(int gridX, int gridY, QColor color);
    void drawGrid(int gridSize);
    void plotCirclePoints(int centerX, int centerY, int x, int y, QColor color);
    void animatePoints(const QVector<QPoint> &points, int centerX, int centerY, QColor color, int delay_ms = 50);
    void drawCircleInstantly(const CircleData &circle);
};
#endif // MAINWINDOW_H
