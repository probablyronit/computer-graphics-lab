#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPainter>
#include <QDebug>
#include <cmath>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    calculationTimer() // Explicitly initialize member
{
    ui->setupUi(this);
    centerInGridCoords = QPoint(-1, -1);

    // spinBox controls grid size
    ui->spinBox->setValue(20);
    // spinBox_2 is Major Axis (rx)
    ui->spinBox_2->setValue(20);
    // spinBox_3 is Minor Axis (ry)
    ui->spinBox_3->setValue(10);
    drawGrid(ui->spinBox->value());

    animationTimer = new QTimer(this);
    connect(animationTimer, &QTimer::timeout, this, &MainWindow::animateDrawingStep);

    connect(ui->frame, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_Pressed()));
    connect(ui->frame, SIGNAL(sendMousePosition(QPoint&)), this, SLOT(showMousePosition(QPoint&)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMousePosition(QPoint &pos)
{
    sc_x = pos.x();
    sc_y = pos.y();
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int graphX = floor((double)(sc_x - snappedOriginX) / gridSize);
    int graphY = floor((double)(sc_y - snappedOriginY) / gridSize);
    ui->mouse_movement->setText("Coordinate: (" + QString::number(graphX) + ", " + QString::number(graphY) + ")");
}

void MainWindow::Mouse_Pressed()
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int graphX = floor((double)(sc_x - snappedOriginX) / gridSize);
    int graphY = floor((double)(sc_y - snappedOriginY) / gridSize);
    centerInGridCoords.setX(graphX);
    centerInGridCoords.setY(graphY);
    redrawAllShapes();
}

void MainWindow::highlightBox(int gridX, int gridY, QColor color)
{
    if (ui->frame->pixmap().isNull()) return;
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) return;
    int centerX = ui->frame->width() / 2;
    int centerY = ui->frame->height() / 2;
    int snappedOriginX = centerX - (centerX % gridSize);
    int snappedOriginY = centerY - (centerY % gridSize);
    int pixelX = snappedOriginX + gridX * gridSize;
    int pixelY = snappedOriginY + gridY * gridSize;
    QPixmap pm = ui->frame->pixmap();
    QPainter painter(&pm);
    painter.fillRect(pixelX, pixelY, gridSize, gridSize, color);
    painter.end();
    ui->frame->setPixmap(pm);
}

// Plots points with 4-way symmetry for ellipses
void MainWindow::plotEllipsePoints(int centerX, int centerY, int x, int y, QColor color)
{
    highlightBox(centerX + x, centerY + y, color);
    highlightBox(centerX - x, centerY + y, color);
    highlightBox(centerX + x, centerY - y, color);
    highlightBox(centerX - x, centerY - y, color);
}

void MainWindow::drawGrid(int gridSize)
{
    QPixmap pix(ui->frame->width(), ui->frame->height());
    pix.fill(Qt::black);
    QPainter painter(&pix);
    if (gridSize > 0) {
        painter.setPen(Qt::NoPen);
        painter.setBrush(QBrush(QColor(80, 80, 80)));
        int centerX = pix.width() / 2;
        int centerY = pix.height() / 2;
        int snappedOriginX = centerX - (centerX % gridSize);
        int snappedOriginY = centerY - (centerY % gridSize);
        painter.drawRect(0, snappedOriginY, pix.width(), gridSize);
        painter.drawRect(snappedOriginX, 0, gridSize, pix.height());
        painter.setPen(QPen(QColor(40, 40, 40), 1));
        for (int x = 0; x < pix.width(); x += gridSize) {
            painter.drawLine(x, 0, x, pix.height());
        }
        for (int y = 0; y < pix.height(); y += gridSize) {
            painter.drawLine(0, y, pix.width(), y);
        }
    }
    painter.end();
    ui->frame->setPixmap(pix);
}

void MainWindow::on_clear_clicked()
{
    if(animationTimer->isActive()) {
        animationTimer->stop();
    }
    animationPointQueue.clear();
    ui->draw_line->setEnabled(true);
    ui->pushButton_2->setEnabled(true);
    ui->pushButton_3->setEnabled(true);
    ui->clear->setEnabled(true);

    centerInGridCoords = QPoint(-1, -1);
    drawnEllipses.clear();
    drawGrid(ui->spinBox->value());
    if(ui->label) {
        ui->label->setText("Time: ");
    }
}

// ===================================================================
// DDA ELLIPSE
// ===================================================================
void MainWindow::on_draw_line_clicked()
{
    if (centerInGridCoords.x() == -1) return;
    int rx = ui->spinBox_2->value(); // Major Axis
    int ry = ui->spinBox_3->value(); // Minor Axis
    if (rx <= 0 || ry <= 0) return;

    QVector<QPoint> pointsToAnimate;
    int computationCount = 0;

    calculationTimer.start();
    float theta_step = 1.0 / std::max(rx, ry);
    for (float theta = 0; theta <= M_PI / 2 + theta_step; theta += theta_step) {
        computationCount++;
        int x = round(rx * cos(theta));
        int y = round(ry * sin(theta));
        if (pointsToAnimate.isEmpty() || pointsToAnimate.last() != QPoint(x, y)) {
            pointsToAnimate.append(QPoint(x, y));
        }
    }
    qint64 timeTaken = calculationTimer.nsecsElapsed();
    qDebug() << "DDA Ellipse computations:" << computationCount;
    if(ui->label) {
        ui->label->setText("DDA Time: " + QString::number(timeTaken) + " ns");
        ui->label_2->setText("Computations: " + QString::number(computationCount));
    }
    startAnimation(pointsToAnimate, Ellipse_DDA);
}

// ===================================================================
// BRESENHAM/MIDPOINT ELLIPSE
// ===================================================================
void MainWindow::on_pushButton_2_clicked()
{
    if (centerInGridCoords.x() == -1) return;
    int rx = ui->spinBox_2->value(); // Major Axis
    int ry = ui->spinBox_3->value(); // Minor Axis
    if (rx <= 0 || ry <= 0) return;

    QVector<QPoint> pointsToAnimate;
    int computationCount = 0;

    calculationTimer.start();
    long long rx2 = (long long)rx * rx;
    long long ry2 = (long long)ry * ry;

    // Region 1
    long long x = 0, y = ry;
    long long p1 = ry2 - rx2 * ry + (0.25 * rx2);
    while (2 * ry2 * x < 2 * rx2 * y) {
        computationCount++;
        pointsToAnimate.append(QPoint(x, y));
        x++;
        if (p1 < 0) {
            p1 += 2 * ry2 * x + ry2;
        } else {
            y--;
            p1 += 2 * ry2 * x - 2 * rx2 * y + ry2;
        }
    }

    // Region 2
    long long p2 = ry2 * (x + 0.5) * (x + 0.5) + rx2 * (y - 1) * (y - 1) - rx2 * ry2;
    while (y >= 0) {
        computationCount++;
        pointsToAnimate.append(QPoint(x, y));
        y--;
        if (p2 > 0) {
            p2 += -2 * rx2 * y + rx2;
        } else {
            x++;
            p2 += 2 * ry2 * x - 2 * rx2 * y + rx2;
        }
    }
    qint64 timeTaken = calculationTimer.nsecsElapsed();
    qDebug() << "Bresenham Ellipse computations:" << computationCount;
    if(ui->label) {
        ui->label->setText("Bresenham Time: " + QString::number(timeTaken) + " ns");
        ui->label_2->setText("Computations: " + QString::number(computationCount));
    }
    startAnimation(pointsToAnimate, Ellipse_Bresenham);
}

// ===================================================================
// CARTESIAN ELLIPSE
// ===================================================================
void MainWindow::on_pushButton_3_clicked()
{
    if (centerInGridCoords.x() == -1) return;
    int rx = ui->spinBox_2->value(); // Major Axis
    int ry = ui->spinBox_3->value(); // Minor Axis
    if (rx <= 0 || ry <= 0) return;

    QVector<QPoint> pointsToAnimate;
    int computationCount = 0;

    calculationTimer.start();
    // y = ry * sqrt(1 - (x*x)/(rx*rx))
    for (int x = 0; x <= rx; x++) {
        computationCount++;
        double y_exact = (double)ry * sqrt(1.0 - ((double)x * x) / ((double)rx * rx));
        int y = round(y_exact);
        if (pointsToAnimate.isEmpty() || pointsToAnimate.last() != QPoint(x, y)) {
            pointsToAnimate.append(QPoint(x, y));
        }
    }
    qint64 timeTaken = calculationTimer.nsecsElapsed();
    qDebug() << "Cartesian Ellipse computations:" << computationCount;
    if(ui->label) {
        ui->label->setText("Cartesian Time: " + QString::number(timeTaken) + " ns");
        ui->label_2->setText("Computations: " + QString::number(computationCount));
    }
    startAnimation(pointsToAnimate, Ellipse_Cartesian);
}

void MainWindow::startAnimation(const QVector<QPoint>& points, Algorithm algo)
{
    if(animationTimer->isActive()) {
        animationTimer->stop();
    }
    animationPointQueue.clear();

    ui->draw_line->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->clear->setEnabled(false);

    animationPointQueue = points;

    // Changed ellipse colors
    if (algo == Ellipse_DDA) {
        currentAnimationColor = QColor(255, 0, 255); // Magenta
    } else if (algo == Ellipse_Bresenham) {
        currentAnimationColor = QColor(255, 165, 0); // Orange
    } else if (algo == Ellipse_Cartesian) {
        currentAnimationColor = QColor(0, 0, 255);   // Blue
    }

    currentAnimationCenterGrid = centerInGridCoords;

    // Store properties of the ellipse being animated
    currentAnimatingEllipse.centerGrid = centerInGridCoords;
    currentAnimatingEllipse.rx = ui->spinBox_2->value();
    currentAnimatingEllipse.ry = ui->spinBox_3->value();
    currentAnimatingEllipse.algo = algo;

    animationTimer->start(75);
}

void MainWindow::animateDrawingStep()
{
    if (animationPointQueue.isEmpty()) {
        animationTimer->stop();

        // After animation, save the completed ellipse
        if (currentAnimatingEllipse.rx > 0) {
            drawnEllipses.append(currentAnimatingEllipse);
            currentAnimatingEllipse.rx = 0;
        }

        ui->draw_line->setEnabled(true);
        ui->pushButton_2->setEnabled(true);
        ui->pushButton_3->setEnabled(true);
        ui->clear->setEnabled(true);
        return;
    }

    QPoint p = animationPointQueue.takeFirst();
    plotEllipsePoints(currentAnimationCenterGrid.x(), currentAnimationCenterGrid.y(), p.x(), p.y(), currentAnimationColor);
}

void MainWindow::redrawAllShapes()
{
    drawGrid(ui->spinBox->value());

    int gridSize = ui->spinBox->value();
    if(gridSize <= 0) return;

    int frameCenterX = ui->frame->width() / 2;
    int frameCenterY = ui->frame->height() / 2;
    int snappedOriginX = frameCenterX - (frameCenterX % gridSize);
    int snappedOriginY = frameCenterY - (frameCenterY % gridSize);

    // Redraw all completed ellipses
    for (const EllipseDef &ellipse : drawnEllipses)
    {
        int cx = ellipse.centerGrid.x();
        int cy = ellipse.centerGrid.y();
        int rx = ellipse.rx;
        int ry = ellipse.ry;
        QColor color;

        // Changed ellipse colors to match animation
        if (ellipse.algo == Ellipse_DDA) { color = QColor(255, 0, 255); }      // Magenta
        else if (ellipse.algo == Ellipse_Bresenham) { color = QColor(255, 165, 0); } // Orange
        else { color = QColor(0, 0, 255); }                                     // Blue

        if (ellipse.algo == Ellipse_DDA) {
            float theta_step = 1.0 / std::max(rx, ry);
            for (float theta = 0; theta <= M_PI / 2 + theta_step; theta += theta_step) {
                plotEllipsePoints(cx, cy, round(rx * cos(theta)), round(ry * sin(theta)), color);
            }
        } else if (ellipse.algo == Ellipse_Bresenham) {
            long long rx2 = (long long)rx * rx, ry2 = (long long)ry * ry;
            long long x = 0, y = ry;
            long long p1 = ry2 - rx2 * ry + (0.25 * rx2);
            while (2 * ry2 * x < 2 * rx2 * y) {
                plotEllipsePoints(cx, cy, x, y, color);
                x++;
                if (p1 < 0) { p1 += 2 * ry2 * x + ry2; }
                else { y--; p1 += 2 * ry2 * x - 2 * rx2 * y + ry2; }
            }
            long long p2 = ry2 * (x + 0.5) * (x + 0.5) + rx2 * (y - 1) * (y - 1) - rx2 * ry2;
            while (y >= 0) {
                plotEllipsePoints(cx, cy, x, y, color);
                y--;
                if (p2 > 0) { p2 += -2 * rx2 * y + rx2; }
                else { x++; p2 += 2 * ry2 * x - 2 * rx2 * y + rx2; }
            }
        } else if (ellipse.algo == Ellipse_Cartesian) {
            for (int x = 0; x <= rx; x++) {
                plotEllipsePoints(cx, cy, x, round((double)ry * sqrt(1.0 - ((double)x*x)/((double)rx*rx))), color);
            }
        }
    }

    if(centerInGridCoords.x() != -1) {
        // Changed center point color
        highlightBox(centerInGridCoords.x(), centerInGridCoords.y(), Qt::white);
    }
}

// This slot is connected to the Grid Size spinBox
void MainWindow::on_spinBox_valueChanged(int arg1)
{
    redrawAllShapes();
}

// Connected to Major Axis (rx) spinBox
void MainWindow::on_spinBox_2_valueChanged(int arg1)
{

}

// Connected to Minor Axis (ry) spinBox
void MainWindow::on_spinBox_3_valueChanged(int arg1)
{

}

