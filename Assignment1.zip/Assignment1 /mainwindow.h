#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QList>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

enum class Algorithm { DDA, Bresenham };

struct DrawnLine {
    QPoint startGrid;
    QPoint endGrid;
    Algorithm algo;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void Mouse_Pressed();
    void showMousePosition(QPoint &pos);
    void on_pushButton_2_clicked();
    void on_DDA_clicked();
    void on_Bresenham_clicked();
    void on_spinBox_valueChanged(int arg1);
    void on_clearLinesButton_clicked();

private:
    Ui::MainWindow *ui;

    QPoint lastPoint1;
    QPoint lastPoint2;
    QPoint center;

    QList<DrawnLine> drawnLines;

    void addPatch(int x, int y, int gridSize, QColor color);

    void drawDDA(const QPoint& start, const QPoint& end);
    void drawBresenham(const QPoint& start, const QPoint& end);
    void drawLineH(const QPoint& p1, const QPoint& p2);
    void drawLineV(const QPoint& p1, const QPoint& p2);

    QPoint pixelToGrid(const QPoint& pixelPoint);
    QPoint gridToPixel(const QPoint& gridPoint);
};
#endif // MAINWINDOW_H
